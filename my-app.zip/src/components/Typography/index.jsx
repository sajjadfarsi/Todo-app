// Using typography component for handling senteces and word in the application
const Typography = (props) => {
  return <p>test</p>;
};

export default Typography;
